## CS250 A6
## Submitted to : Prof. Basavaraj Talwar 
## Team members


Chintamani Masthanaiah   --- 191CS115 \
Venkata Sravani --- 191CS223 \
V Madhan Kumar --- 191CS260 \
Vinesh S Talpankar --- 191CS265

## Project Description:
Our task was to design nPower Processor Pipeline, integrating all the modules (ALU Control,Control Unit, Register File,Instruction Fetch, Instruction Decode, Data Memory,Write back). We have designed nPower processor Pipeline on MakerChip IDLE using TL Verilog.

## Contributions:
As it is a team project all four of us have contributed equally to the project,we have made ourselves into 2 groups with 2 members each designing specific set of modules.

Madhan, Vinesh: Control Unit, ALU, Register File, Testing of the pipeline.

Sravani, Masthanaiah: Instruction Fetch,Instruction Decode, PC related modules, Data Memory, Pipeline.

## Makerchip links

[ALU_64-bit](https://www.makerchip.com/sandbox/0ERfWhB9B/048hz98)

[ALU control unit](https://www.makerchip.com/sandbox/0n5fGhpQE/01jh6B1)

[Instruction Fetch](http://makerchip.com/sandbox/02kfkhXDM/066hP0L)

[Datapath](https://www.makerchip.com/sandbox/0n5fGhpQE/076hzVX)

[Pipeline testing](http://makerchip.com/sandbox/02kfkhXDM/0xGhL1L#)

[Fibonacci program through pipeline](http://makerchip.com/sandbox/02kfkhXDM/076hzmx)


## Date of Submission : 01-05-2021

## Start of the project : 15-04-2021

## References 
nPower ISA manual\
Building a RISC V CPU Core course on Edx platform.\
RISC V pipeline